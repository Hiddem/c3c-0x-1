<?php
/**
 * english language file for c3chart plugin
 *
 * @author Jason Xun Xu <dev@jasonxu.net>
 */

// keys need to match the config setting name
$lang['url_yaml'] = 'URL of JS-YAML (js-yaml.js)';
$lang['url_d3'] = 'URL of d3.js';
$lang['url_c3'] = 'URL of c3.js';
$lang['url_c3_css'] = 'URL of CSS file of c3.js';



//Setup VIM: ex: et ts=4 :

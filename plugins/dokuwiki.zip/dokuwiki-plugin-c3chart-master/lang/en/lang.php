<?php
/**
 * English language file for c3chart plugin
 *
 * @author Jason Xun Xu <dev@jasonxu.net>
 */

// menu entry for admin plugins
// $lang['menu'] = 'Your menu entry';

// custom language strings for the plugin
// $lang['fixme'] = 'FIXME';



//Setup VIM: ex: et ts=4 :

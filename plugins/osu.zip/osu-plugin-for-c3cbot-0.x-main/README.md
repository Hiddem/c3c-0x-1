# osu-plugin-for-c3cbot-0.x
 - assets đều được lấy từ https://github.com/Moorad/the-beautiful-bot
 - Sử dụng cho https://github.com/c3cbot/c3c-0x
 - Drive link br: https://drive.google.com/file/d/1mmdb5juvZGHWxsBrgH5z1WclChkCm-T6/view?usp=sharing
 - Drive link (mirai): https://drive.google.com/file/d/1uu0d6QdlWAsNe9EBhqLjqijwj4Xte7of/view?usp=sharing
 - Khi thực hiện lệnh sẽ cho ra stats card giống như sau:
 <img src = 'https://cdn.discordapp.com/attachments/837998797702430730/845664312488099840/osu_ZzMattytwokzZ.jpg'>

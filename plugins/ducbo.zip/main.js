const axios = global.nodemodule["axios"];
const fetch = global.nodemodule["node-fetch"];
const streamBuffers = global.nodemodule["stream-buffers"];

module.exports = {
	Bo: async function (type, data) {
		axios({
			url: `https://api.berver.tech/duckbo`,
			method: "GET",
			mode: "no-cors"
		}).then(res => {
			let imgLink = res.data.data;
			if (imgLink) {
				console.log(`[ CHECK IMG URL] ${imgLink}`);
				async function lmao() {
					let r = await fetch(imgLink);
					if (r.status == 200) {
						let buf = await r.buffer();
						let img = new streamBuffers.ReadableStreamBuffer({frequency: 10, chunkSize: 1024});
						img.path = "Jimmy.jpg", img.put(buf), img.stop();
						data.return({
							handler: "internal-raw", 
							data: {
								body: "cute <3",
								attachment: img
							}
						})
					}else {
						data.return({
							handler: "internal", 
							data: "err"
						})
					}
				};
				lmao()
			}
		})
	}
}